import 'bootstrap/dist/css/bootstrap.css';

export default function ResultList({ results }) {
    return (
        <div className="resultList">
            <table className="table table-hover rounded-1 overflow-hidden">
                <thead className="table-dark">
                    <tr>
                        <th scope="col">N</th>
                        <th scope="col">X</th>
                        <th scope="col">Y</th>
                        <th scope="col">Z</th>
                    </tr>
                </thead>
                <tbody>
                    {   
                        results!== null && Object.entries(results).map(([key, coordinates]) => 
                            <tr key={key} data={coordinates}>
                                <td>{key}</td>
                                <td>{coordinates.x}</td>
                                <td>{coordinates.y}</td>
                                <td>{coordinates.z}</td>
                            </tr>
                        )
                    }
                </tbody>
            </table>
        </div>
    );
}