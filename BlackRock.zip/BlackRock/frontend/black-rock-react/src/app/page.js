"use client";
import 'bootstrap/dist/css/bootstrap.css';
import { useState } from "react";

import ResultList from './Components/ResultList';

export default function Home() {
    const url = process.env.NEXT_PUBLIC_API_URL;

    const [variables, setVariables] = useState({ x0: 0, y0: 0, z0: 0, sigma: 0, rho: 0, beta: 0, deltaT: 0 });
    const [result, setResult] = useState(null);

    const handleInputChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        setVariables(values => ({ ...values, [name]: value }));
    };
    
    const hasNull = () => {
        for (let key in variables) {
            if (variables[key] === null || variables[key].length === 0) {
                return true;
            }
        }
        return false;
    };

    const handleSubmit = async () => {
        if (hasNull()) {
            alert("Please enter all required variables");
        } else {
            try {
                const response = await fetch(`${url}/process_equation`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(variables)
                });
                const data = await response.json();
                setResult(data);
            } catch (error) {
                console.error("Error processing variables: ", error);
            }
        }
    };

    return (
        <div>
            <div>
                <nav className="navbar navbar-expand-lg navbar-dark bg-dark">

                    <a className="navbar-brand" href="#">AI Labs | Full Stack Case Study</a>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <div className="ms-auto runButn">
                            <button type="button" className="btn btn-outline-light" onClick={handleSubmit}>Run</button>
                        </div>
                    </div>
                </nav>
                <div className="card inputComponent">
                    <div className="card-header">Inputs</div>
                    <div className="card-body">
                        <div className="container">
                            <form>
                                <div className="row">
                                    <div className="col">
                                        <label htmlFor="inputEmail4">x0</label>
                                        <input type="number" className="form-control" name="x0" value={variables.x0} placeholder="Value" onChange={handleInputChange} />
                                    </div>
                                    <div className="col">
                                        <label htmlFor="inputPassword4">y0</label>
                                        <input type="number" className="form-control" name="y0" value={variables.y0} placeholder="Value" onChange={handleInputChange} />
                                    </div>
                                    <div className="col">
                                        <label htmlFor="inputPassword4">z0</label>
                                        <input type="number" className="form-control" name="z0" value={variables.z0} placeholder="Value" onChange={handleInputChange} />
                                    </div>
                                    <div className="col">
                                        <label htmlFor="inputPassword4">Sigma</label>
                                        <input type="number" className="form-control" name="sigma" value={variables.sigma} placeholder="Value" onChange={handleInputChange} />
                                    </div>
                                    <div className="col">
                                        <label htmlFor="inputPassword4">Rho</label>
                                        <input type="number" className="form-control" name="rho" value={variables.rho} placeholder="Value" onChange={handleInputChange} />
                                    </div>
                                    <div className="col">
                                        <label htmlFor="inputPassword4">Beta</label>
                                        <input type="number" className="form-control" name="beta" value={variables.beta} placeholder="Value" onChange={handleInputChange}/>
                                    </div>
                                    <div className="col">
                                        <label htmlFor="inputPassword4">Delta t</label>
                                        <input type="number" className="form-control" name="deltaT" value={variables.deltaT} placeholder="Value" onChange={handleInputChange}/>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
            <div className="resultsCmpt">
                <div className="card">
                    <div className="card-header">
                        Results
                    </div>
                    <div className="card-body">
                        <ResultList results={result}/>
                    </div>
                </div>
            </div>
        </div>
    );
}
