# About the Project

A simple app that simulates a discrete time dynamical system


### Built With

- [Next.js](https://nextjs.org/?ref=cal.com)
- [React.js](https://reactjs.org/?ref=cal.com)
- [Bootstrap CSS](https://getbootstrap.com/)
- [Fast API](https://fastapi.tiangolo.com/)

## Getting Started
### Prerequisites
- Npm
- Virtualenv (Python virtual environment)
  ```sh
   pip install virtualenv
   ```
- FastAPI
  ```sh
   pip install fastapi
   ```
-  Uvicorn
  ```sh
   pip install "uvicorn[standard]"
   ```   

## Development

### Setup

1. Clone the repo or download ZIP file. 

#### Backend Setup
1. Go to the backend project folder
  
   ```sh
   cd backend
   ```
2. Create python virtual environment, activate, and install requirements
   ```sh
   py -m venv env 
   .\env\Scripts\activate
   pip install -r requirements.txt
   ```
3. Run app
   ```sh
   uvicorn main:app --host localhost --port 8080
   ```

4. Deactivate once done
   ```sh
   deactivate
   ```

#### Frontend Setup
1. Go to the frontend project folder
   ```sh
   cd frontend\black-rock-react
   ```
2. Initialize node modules
   ```sh
   npm install
   ```
2. Run app
   ```sh
   npm run dev
   ```

## Notes
- Incredibly large numbers are returned as "" as NaN and INF are unable to be decoded. 

