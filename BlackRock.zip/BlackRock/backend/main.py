import typing
from fastapi import FastAPI
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
import orjson

class ORJSONResponse(JSONResponse):
    """Enables NAN and INF to be encoded, taken from https://github.com/tiangolo/fastapi/issues/459"""
    media_type = "application/json"

    def render(self, content: typing.Any) -> bytes:
        return orjson.dumps(content)
    
app = FastAPI(default_response_class=ORJSONResponse)

#Lines 18 to 29 allows Cross Domain requests 
origins = [
    "http://localhost:8080",
    "http://localhost:8000",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
    
def simulate_dynamical_system(point: dict, params: dict):
    """
    Calculates xn+1, yn+1, and zn+1 from xn, yn, and zn and other parameters

    Parameters:
        point (dict): Contains coordinates
        params (dict): Contains sigma, rho, beta, and deltaT

    Returns:
        (dict): Contains coordinates {x, y, z} 
    """
    sigma = params['sigma']
    rho = params['rho']
    beta = params['beta']
    deltaT = params['deltaT']

    x, y, z = point['x'], point['y'], point['z']

    newX = x + z * sigma*(y - x) * deltaT
    newY = y + (x*(rho - z) - (z * y)) * deltaT
    newZ = z + ((x*y) - (beta*z)) * deltaT

    return {'x':newX, 'y':newY, 'z':newZ}
    
@app.get("/")
def read_root():
    return {"Hello": "World"}

@app.post("/process_equation")
async def process_equation(variables: dict):
    """
    Simulates discrete time dynamical system for 20 time steps

    Parameters:
        variables (dict): Contains coordinates and sigma, rho, beta, and deltaT

    Returns:
        results_dict(dict): Contains future time N as key and coordinates {x, y, z} as value
    """

    for k, v in variables.items():
        variables[k] = float(v)

    results_dict = {}
    initPoint = {'x':variables['x0'], 'y':variables['y0'], 'z':variables['z0']}
    params = {'sigma': variables['sigma'], 'rho': variables['rho'], 'beta': variables['beta'], 'deltaT': variables['deltaT'] }

    results_dict['0'] = initPoint

    for x in range(0, 20):
        point = simulate_dynamical_system(results_dict[str(x)], params)
        results_dict[str(x+1)] = point
    
    return jsonable_encoder(results_dict)