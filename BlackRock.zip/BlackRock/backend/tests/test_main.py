import json
from fastapi.testclient import TestClient
from ..main import app

client = TestClient(app)

def test_read_main():
    response = client.get("/")
    assert response.status_code == 200
    assert response.json() == {"Hello": "World"}

def test_post_zero():
    item = {"x0": 0,"y0": 0,"z0":0,"sigma": 0,"rho": 0,"beta": 0,"deltaT": 0}
    f = open('./jsonTest/0.json')
    expectedOutput = json.load(f)
    response = client.post(
        "/process_equation/",
        json=item,
    )
    assert response.status_code == 200
    assert response.json() == expectedOutput